import java.util.ArrayList;
import java.util.concurrent.TimeUnit;
import java.util.*;

public class Bus extends Thread {
    public int id;
    public Stop location;
    public  ArrayList<Stop> route;
    public double secondsElapsed = 0;
    public int speed = 1;
    private Iterator<Stop> iter;
    private int maxAllottedTime;
    private ArrayList<Stop> stopsPassed = new ArrayList<>();


    public Bus(int id, ArrayList<Stop> route, int maxTime) {
        this.id = id;
        this.route = route;
        location = route.get(0);
        iter = route.iterator();
        maxAllottedTime = maxTime;

    }

    public void updateLocation(Stop loc) {
        stopsPassed.add(loc);
        location.busDeparted();
        location = loc;
        System.out.println("Moving bus " + id + " to " + location.toString());
        location.newBusArrived(this);

    }

    public void move() {
        try {
            TimeUnit.SECONDS.sleep(2 * speed); //takes 2 seconds to get from 1 stop to another
            secondsElapsed += 2 * speed;
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        updateLocation(iter.next());

        if(secondsElapsed > maxAllottedTime) {
            speed += .2;
            System.out.println("Bus " + id + " slowing down");
        }
    }

    //We still have our method to waste time at a congested bus stop -- but happily, it's never called,
    //because we never have congested bus stops!
    public void wasteTime() {
        try {
            TimeUnit.SECONDS.sleep(1);
            secondsElapsed += 1;
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }

    public void startRoute() {
        while(iter.hasNext()) {
            move();
        }
        System.out.println("Bus " + id + " completed in " + secondsElapsed + " minutes");
        System.out.println("Passed stops " + stopsPassed.toString());
        location.busDeparted();
        location = null;
    }

    public void run() {
        startRoute();
    }

    public void setSpeed(int speed) {
        this.speed = speed;
    }


  //goExpress() circumvents the bus-bunching by checking if a bus stop is full before proceeding to park there.
  //Each bus stop has a maximum capacity of one bus, so if a bus sees that its next stop is full, it will skip
  //that stop knowing that it wouldn't be able to park anyway. While this results in one bus skipping the stop,
  //it decreases overall bus waiting and bunching.
  public void goExpress() {
      // Find the index of the next stop
      int nextStopIndex = route.indexOf(location) + 1;
      if (nextStopIndex >= route.size()) {
          System.out.println("Bus " + id + " is already at the last stop.");
          return; // No next stop, cannot go express
      }

      Stop nextStop = route.get(nextStopIndex);
      if (nextStop.isFull()) {
          // Next stop is full, try to go express
          int nextNextStopIndex = nextStopIndex + 1;
          if (nextNextStopIndex >= route.size()) {
              System.out.println("Bus " + id + " is already at the second last stop.");
              return; // No stop after next, cannot go express
          }

          Stop nextNextStop = route.get(nextNextStopIndex);
          if (!nextNextStop.isFull()) {
              // Found a non-full stop after next stop, going express
              iter.next();
              iter.next();
              updateLocation(nextNextStop);
              System.out.println("Bus " + id + " is going express to " + nextNextStop);
          } else {
              System.out.println("Bus " + id + " cannot go express, next stops are also full.");
          }
      }
  }


}
