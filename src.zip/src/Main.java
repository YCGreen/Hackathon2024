import java.util.*;
import java.util.concurrent.TimeUnit;

/* The solution we implemented here is mainly in our method Bus.goExpress(), see in class Bus.
 */
public class Main {
    public static void main(String[] args) {
        //A route is a list of stops. One stop may be present in several different routes. A stop has max capacity of one bus.
        ArrayList<Bus> buses = new ArrayList<Bus>();
        ArrayList<Stop> route = new ArrayList<Stop>();

        Random rand = new Random();

        for(int i = 0; i < 10; i++) {
            route.add(new Stop(i));
        }
        System.out.println("Size of route ArrayList: " + route.size());

        for(int i = 0; i < 10; i++) {
            buses.add(new Bus(i, route, rand.nextInt(10, 20)));
            buses.get(i).start(); //wait 2 at stop
        }

        //Same initialization and beginning to run buses; here we stagger the bus so that they leave with 3-minute padding
        //in between each bus, giving each a better head start to avoid bunching.
        for(int i = 0; i < buses.size(); i++) {
            buses.get(i).run();
            try {
                TimeUnit.SECONDS.sleep(3);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }


    }

}