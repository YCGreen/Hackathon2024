public class ParkingLot extends Stop{
    int id;

    public ParkingLot(int id) {
        super(id);
    }



}
