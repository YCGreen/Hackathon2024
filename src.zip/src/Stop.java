public class Stop {
    public Bus busPresent;
    public int id;
    public boolean full = false;

    public Stop(int id) {
        this.id = id;
    }

    public int getLocation() {
        return id;
    }
    public Bus getBusPresent() {
        return busPresent;
    }

    public void newBusArrived(Bus bus) {
        if(full) {
            bus.goExpress();
        }
        else {
            full = true;
            busPresent = bus;
        }
    }

    public void busDeparted() {
        busPresent = null;
        full = false;
    }

    public String toString() {
        return "Stop " + id;
    }

    public boolean isFull() {
        return full;
    }
}
