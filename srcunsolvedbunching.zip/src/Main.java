import java.util.*;
import java.util.concurrent.TimeUnit;

/*This program simulates a series of buses (10, although the number is adjustable), each on a 10-stop route.
There is no solution in place here to prevent bus-bunching.
 */
public class Main {
    public static void main(String[] args) {
        //A route is a list of stops. One stop may be present in several different routes. A stop has max capacity of two buses; once
        // that's exceeded, they start to slow down.
        ArrayList<Bus> buses = new ArrayList<Bus>();
        ArrayList<Stop> route = new ArrayList<Stop>();

        Random rand = new Random();

        //Here we're creating a route that we'll use for our simulated line of buses. could link to data set
        for(int i = 0; i < 10; i++) {
            route.add(new Stop(i));
        }
        System.out.println("Size of route ArrayList: " + route.size());

        for(int i = 0; i < 10; i++) {
            //Buses are initialized here with an ID, a route, and a random number between 10-20 that represents
            //how quickly they're expected to finish their routes (translate seconds to minutes for more realistic
            //timing). The number is randomized to better simulate random small delays that may arise along a route;
            //see Bus.move() for more information on this element of delay.
            buses.add(new Bus(i, route, rand.nextInt(10, 20)));
            buses.get(i).start();
        }

        //Begin running buses along the route
        for(int i = 0; i < buses.size(); i++) {
            buses.get(i).run();
        }

    }







}