import java.util.ArrayList;
import java.util.concurrent.TimeUnit;
import java.util.*;

/* When run() is called, it sets off a chain reaction. startRoute() is called first; startRoute() then calls move() to move the bus
along every stop on its route. move() calls updateLocation(), which alerts each bus stop which buses have arrived.
 */
public class Bus extends Thread {
    public int id;
    public Stop location;
    public  ArrayList<Stop> route;
    public double secondsElapsed = 0;
    public int speed = 1;
    private Iterator<Stop> iter;
    private int maxAllottedTime;

    public Bus(int id, ArrayList<Stop> route, int maxTime) {
        this.id = id;
        this.route = route;
        location = route.get(0);
        iter = route.iterator();
        maxAllottedTime = maxTime;

    }

    public int getBusId() {
        return id;
    }

    public void updateLocation(Stop loc) {
        location.busDeparted();
        location = loc;
        System.out.println("Moving bus " + id + " to " + location.toString());
        location.newBusArrived(this);

    }

    public void move() {
        try {
            TimeUnit.SECONDS.sleep(2 * speed); //It takes 2 minutes to get from 1 stop to another (this number is easily replaceable)
            secondsElapsed += 2 * speed;
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        updateLocation(iter.next());


        //Wikipedia: "The classical theory causal model for irregular intervals is based on the observation
        // that a late bus tends to get later and later as it completes its run." To more accurately simulate this,
        //we decreased speed at each stop past a certain expected amount of time the bus route might take;
        //this makes the bus later and later as it lags on its route.
        if(secondsElapsed > maxAllottedTime) {
            speed += .2;
            System.out.println("Bus " + id + " slowing down");
        }
    }

    //Method to waste time delaying at a congested bus stop as buses ahead proceed
    public void wasteTime(int time) {
        try {
            TimeUnit.SECONDS.sleep(time);
            secondsElapsed += time;
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }

    public void startRoute() {
        while(iter.hasNext()) {
            move();
        }
        System.out.println("Bus " + id + " completed in " + secondsElapsed + " minutes");
        location.busDeparted();
        location = null;
    }

    public void run() {
        startRoute();
    }

    public void setSpeed(int speed) {
        this.speed = speed;
    }



}

