
public class Stop {
    public int bussesPresent = 0;
    public int id;

    public Stop(int id) {
        this.id = id;
    }

    public int getLocation() {
        return id;
    }
    public int getBussesPresent() {
        return bussesPresent;
    }

    public void newBusArrived(Bus bus) {
        bussesPresent++;
        if(bussesPresent > 2) {
            System.out.println("TOO MANY BUSES! " + bussesPresent + " buses at stop " + id + ", adding bus " + bus.id);
            bus.wasteTime(bussesPresent);
        }
    }

    public void busDeparted() {
        bussesPresent--;
    }

    public String toString() {
        return "Stop " + id;
    }

}

